/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Name of package */
#define PACKAGE "lib3ds"

/* Version number of package */
#define VERSION "1.2.0"

/* Define if using the dmalloc debugging malloc package */
/* #undef WITH_DMALLOC */

